#include "admin.h"
#include "ui_admin.h"


#pragma execution_character_set("utf-8")

admin::admin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::admin)
{
    ui->setupUi(this);
//    adminwidget_title();
}

admin::~admin()
{
    delete ui;
}

void admin::on_textEdit_textChanged()
{

}

void admin::style_init_admin()
{
    QFile styleFile(":/QSS/style_init_admin.qss");
    if(styleFile.open(QIODevice::ReadOnly)){
       qDebug("open success");
       QString setStylesheet(styleFile.readAll());
       this->setStyleSheet(setStylesheet);
       styleFile.close();
    }
    else
    {
        qDebug("open Failed");
    }
}

//void admin::adminwidget_title(){
//    QString title = "管理员界面";
//    setWindowTitle(title);
//}

void admin::on_pushButton_3_clicked()
{
    emit insert_tab_A_signal();
}

void admin::on_pushButton_2_clicked()
{
    emit del_tab_A_signal();
}
