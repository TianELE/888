#ifndef ADMIN_H
#define ADMIN_H

#include <QWidget>
#include <QFile>

#include<SQLconnection.h>

namespace Ui {
class admin;
}

class admin : public QWidget
{
    Q_OBJECT

public:
    explicit admin(QWidget *parent = nullptr);
    void style_init_admin();
    void adminwidget_title();



    Ui::admin *ui;

    ~admin();

private slots:
    void on_textEdit_textChanged();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

signals:
    void insert_tab_A_signal();
    void del_tab_A_signal();

private:
//    Ui::admin *ui;
};

#endif // ADMIN_H
