#include<SQLconnection.h>
#include<dms.h>

void DMS::insert_tab_A()
{
    //id integer primary key,name varchar(100),fformat varchar(20),fclass varchar(20),fpath varchar(150),tempa varchar(20),tempb varchar(20),tempc varchar(20)

    if(adminwidget->ui->textEdit_id->document()->isEmpty()||adminwidget->ui->textEdit_name->document()->isEmpty()||adminwidget->ui->textEdit_format->document()->isEmpty()||adminwidget->ui->textEdit_class->document()->isEmpty()
            ||adminwidget->ui->textEdit_path->document()->isEmpty()/*||adminwidget->ui->textEdit_tempa->document()->isEmpty()||adminwidget->ui->textEdit_tempb->document()->isEmpty()||adminwidget->ui->textEdit_tempc->document()->isEmpty()*/)
    {
            QMessageBox::information(nullptr,"错误", "对象不可为空\n",QMessageBox::Ok,QMessageBox::NoButton);
    }
    else
    {
        int id = 0; QString data1 = NULL;QString data2 = NULL;QString data3 = NULL;QString data4 = NULL;QString data5 = NULL;QString data6 = NULL;QString data7 = NULL;
        id = adminwidget->ui->textEdit_id->toPlainText().toInt();
        data1 = adminwidget->ui->textEdit_name->toPlainText();
        data2 = adminwidget->ui->textEdit_format->toPlainText();
        data3 = adminwidget->ui->textEdit_class->toPlainText();
        data4 = adminwidget->ui->textEdit_path->toPlainText();
        data5 = adminwidget->ui->textEdit_tempa->toPlainText();
        data6 = adminwidget->ui->textEdit_tempb->toPlainText();
        data7 = adminwidget->ui->textEdit_tempc->toPlainText();

        QSqlQuery query;
        query.prepare("INSERT INTO tabone(id,name,fformat,fclass,fpath,tempa,tempb,tempc)VALUES(:id,:name,:fformat,:fclass,:fpath,:tempa,:tempb,:tempc)");
        query.bindValue(":id",id);
        query.bindValue(":name",data1);
        query.bindValue(":fformat",data2);
        query.bindValue(":fclass",data3);
        query.bindValue(":fpath",data4);
        query.bindValue(":tempa",data5);
        query.bindValue(":tempb",data6);
        query.bindValue(":tempc",data7);
        if(!(query.exec())){
            QMessageBox::information(nullptr,"错误", "添加失败\n"+query.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        }
        else {
            createTABLE_A();
        }
    }
}

void DMS::del_tab_A()
{
    //id integer primary key,name varchar(100),fformat varchar(20),fclass varchar(20),fpath varchar(150),tempa varchar(20),tempb varchar(20),tempc varchar(20)

    if(adminwidget->ui->textEdit_id->document()->isEmpty()||adminwidget->ui->textEdit_name->document()->isEmpty()||adminwidget->ui->textEdit_format->document()->isEmpty()||adminwidget->ui->textEdit_class->document()->isEmpty()
            ||adminwidget->ui->textEdit_path->document()->isEmpty()/*||adminwidget->ui->textEdit_tempa->document()->isEmpty()||adminwidget->ui->textEdit_tempb->document()->isEmpty()||adminwidget->ui->textEdit_tempc->document()->isEmpty()*/)
    {
            QMessageBox::information(nullptr,"错误", "对象不可为空\n",QMessageBox::Ok,QMessageBox::NoButton);
    }
    else
    {
        int id = 0; QString data1 = NULL;QString data2 = NULL;QString data3 = NULL;QString data4 = NULL;QString data5 = NULL;QString data6 = NULL;QString data7 = NULL;
        id = adminwidget->ui->textEdit_id->toPlainText().toInt();
        data1 = adminwidget->ui->textEdit_name->toPlainText();
        data2 = adminwidget->ui->textEdit_format->toPlainText();
        data3 = adminwidget->ui->textEdit_class->toPlainText();
        data4 = adminwidget->ui->textEdit_path->toPlainText();
        data5 = adminwidget->ui->textEdit_tempa->toPlainText();
        data6 = adminwidget->ui->textEdit_tempb->toPlainText();
        data7 = adminwidget->ui->textEdit_tempc->toPlainText();

        QSqlQuery query;
        query.prepare("DELETE FROM tabone where id = ?");
        query.addBindValue(id);
        if(!(query.exec())){
            QMessageBox::information(nullptr,"错误", "删除失败\n"+query.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        }
        else {
            createTABLE_A();
        }
    }
}
