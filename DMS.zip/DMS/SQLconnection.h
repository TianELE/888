#ifndef SQL_H
#define SQL_H

#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlTableModel>


static bool createConnection()
{
    QSqlDatabase db;
    if (QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db = QSqlDatabase::database("qt_sql_default_connection");
        qDebug("link success");
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE","qt_sql_default_connection");
    //    db.setHostName("127.0.0.1");
    //    db.setPort(3306);
        db.setDatabaseName("DDB.db");
        db.setUserName("root");
        db.setPassword("123456");
        qDebug("create success");
    }
    if (!db.open())
    {
        QMessageBox::information(nullptr,"错误", "数据库打开失败\n"+db.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return false;
    }

    QSqlQuery query;
    query.exec("create table tabone (id integer primary key,name varchar(100),fformat varchar(20),fclass varchar(20),fpath varchar(150),tempa varchar(20),tempb varchar(20),tempc varchar(20))");
    query.exec("insert into tabone values(1, '基于ESP32的无线数据采集系统设计_高培', 'pdf', '论文', 'D:/WORK/TEST/资料','预留','temp', NULL)");
    query.exec("insert into tabone values(2,'ECG WATCH a real time wireless wearable ECG', 'pdf', '论文', 'D:/WORK/TEST/资料','预留','temp', NULL)");
    query.exec("insert into tabone values(3, 'ziliao1资料3', 'exl', '经验总结', 'dgfgdhr',NULL ,NULL, NULL)");
    query.exec("create table tabtwo (itemid int, file varchar(50))");
    query.exec("insert into tabtwo values(0, 'a')");
    query.exec("insert into tabtwo values(2, 'a')");
    query.exec("insert into tabtwo values(4, 'a')");
    query.exec("insert into tabtwo values(6, 'a')");
    if(!(query.exec())){
        QMessageBox::information(nullptr,"错误", "建表失败\n"+query.lastError().text(),QMessageBox::Ok,QMessageBox::NoButton);
        return false;
    }
    return true;
}

#endif // SQL_H
