﻿#include "dms.h"
#include "ui_dms.h"
#include "SQLconnection.h"
#include <QApplication>


#pragma execution_character_set("utf-8")

DMS::DMS(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::DMS)
{
    ui->setupUi(this);
//    style_init();
    connect(adminwidget,SIGNAL(insert_tab_A_signal()),this,SLOT(insert_tab_A()));
    connect(adminwidget,SIGNAL(del_tab_A_signal()),this,SLOT(del_tab_A()));

    REALtime();
    UIcreate();
}

DMS::~DMS()
{
    delete ui;
}


void DMS::style_init()
{
    QFile styleFile(":/QSS/style_init.qss");
    if(styleFile.open(QIODevice::ReadOnly)){
       qDebug("open success");
       this->ui->stackedWidget->setCurrentIndex(0);
       QString setStylesheet(styleFile.readAll());
       this->setStyleSheet(setStylesheet);
       styleFile.close();
    }
    else
    {
        qDebug("open Failed");
    }
}


void DMS::REALtime()
{
    currentTimeLabel = new QLabel; // 创建QLabel控件
    QTimer *time_timer = new QTimer(this);
    time_timer->start(1000); //每隔1000ms发送timeout的信号
    ui->statusbar->addWidget(currentTimeLabel);
    connect(time_timer, &QTimer::timeout,this,&DMS::time_update);
}
void DMS::time_update()
{
    //[1] 获取时间
    QDateTime current_time = QDateTime::currentDateTime();
    QString timestr = current_time.toString(QStringLiteral( "yyyy-MM-dd hh:mm:ss ddd")); //设置显示的格式
    currentTimeLabel->setText(timestr); //设置label的文本内容为时间

}

void DMS::createTABLE_A()
{

        model = new QSqlTableModel(this);
        model->setTable("tabone");
        model->setEditStrategy(QSqlTableModel::OnManualSubmit);
        model->select();

        model->setHeaderData(0, Qt::Horizontal, tr("ID"));
        model->setHeaderData(1, Qt::Horizontal, tr("名称"));
        model->setHeaderData(2, Qt::Horizontal, tr("格式"));
        model->setHeaderData(3, Qt::Horizontal, tr("分类"));
        model->setHeaderData(4, Qt::Horizontal, tr("路径"));
        model->setHeaderData(5, Qt::Horizontal, tr("其他A"));
        model->setHeaderData(6, Qt::Horizontal, tr("其他B"));
        model->setHeaderData(7, Qt::Horizontal, tr("其他C"));
        ui->tableView_P2->setModel(model);

        ui->tableView_P2->setColumnHidden(0,true);
        ui->tableView_P2->resizeColumnToContents(1);
        ui->tableView_P2->resizeColumnToContents(4);
        ui->tableView_P2->setEditTriggers(QAbstractItemView::NoEditTriggers);

//        ui->tableView_P2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);//均分模式
//        ui->tableView_P2->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);//自适应内容模式
//        ui->tableView_P2->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);//自定义模式
        ui->tableView_P2->horizontalHeader()->setMinimumSectionSize(100);//最小宽度
}

void DMS::createTreeView_A()
{
    QStandardItemModel *treeviewModel = new QStandardItemModel(this);

    ui->treeView_P2->setHeaderHidden(true);//设置表头隐藏
//    treeviewModel->setHorizontalHeaderLabels(QStringList()<<""<<" "<<" ");//设置表头
    ui->treeView_P2->setModel(treeviewModel);//设置model
    ui->treeView_P2->expandAll();//设置展开

    // 一级标题
    QStandardItem *a_Item_1   = new QStandardItem("浙江省");
    QStandardItem *a_Item_2   = new QStandardItem("江苏省");
   // 二级标题
    QStandardItem *b_Item_1_1     = new QStandardItem("杭州市");
    QStandardItem *b_Item_1_2     = new QStandardItem("宁波市");
    QStandardItem *b_Item_1_3     = new QStandardItem("绍兴市");
    QStandardItem *b_Item_2_1     = new QStandardItem("南京市");
    QStandardItem *b_Item_2_2     = new QStandardItem("无锡市");
    QStandardItem *b_Item_2_3     = new QStandardItem("徐州市");
   // 三级标题
    QStandardItem *c_Item_1_1_1 = new QStandardItem("滨江区");
    QStandardItem *c_Item_1_2_1 = new QStandardItem("余姚市");

   // 创建一级节点
    treeviewModel->appendRow(a_Item_1);
    treeviewModel->appendRow(a_Item_2);

   // [2] 创建二级节点
    a_Item_1->appendRow(b_Item_1_1);
    a_Item_1->appendRow(b_Item_1_2);
    a_Item_1->appendRow(b_Item_1_3);

    a_Item_2->appendRow(b_Item_2_1);
    a_Item_2->appendRow(b_Item_2_2);
    a_Item_2->appendRow(b_Item_2_3);

   // [3] 创建三级节点
    b_Item_1_1->appendRow(c_Item_1_1_1);
    b_Item_1_2->appendRow(c_Item_1_2_1);
}


/*void DMS::WEB()
{
//    my_web = new QWebEngineView(ui->page);
    my_web   = ui->page;
//    QWebEngineSettings* settings = QWebEngineSettings::globalSettings();
    my_web->settings()->setAttribute(QWebEngineSettings::PluginsEnabled, true);
    my_web->settings()->setAttribute(QWebEngineSettings::JavascriptEnabled, true);
    my_web->settings()->setAttribute(QWebEngineSettings::JavascriptCanOpenWindows, true);
    my_web->settings()->setAttribute(QWebEngineSettings::JavascriptCanAccessClipboard, true);
    my_web->settings()->setAttribute(QWebEngineSettings::SpatialNavigationEnabled, true);
    my_web->settings()->setAttribute(QWebEngineSettings::LinksIncludedInFocusChain, true);
    my_web->settings()->setAttribute(QWebEngineSettings::Accelerated2dCanvasEnabled, true);
    my_web->settings()->setAttribute(QWebEngineSettings::AutoLoadImages, true);

    my_web->setAttribute(Qt::WA_DeleteOnClose);
    my_web->setWindowFlags(Qt::FramelessWindowHint);   //去除边框
    my_web->setAttribute(Qt::WA_TranslucentBackground, true); //透明

//    my_web->page()->settings()->setAttribute(QWebEngineSettings::PluginsEnabled, true);
//    my_web->setUrl(QUrl("http://192.168.124.6:8081"));
    my_web->setUrl(QUrl("F:/A_Project/m3u8_video/m3u8/index.html"));
    my_web->show();

}
*/
int DMS::get_random_num()
{
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    return (qrand()%100);
}


void DMS::openadminWidget()
{
    adminwidget->show();
    adminwidget->style_init_admin();
}

void DMS::on_pushButton_A_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(1);
    createTABLE_A();
    createTreeView_A();
    qDebug("go to Page2!ok");
}

void DMS::on_action_U_triggered()
{
    this->ui->stackedWidget->setCurrentIndex(0);
    qDebug("go to Page1!ok");
}
void DMS::on_retuen_P2_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(0);
    qDebug("go to Page1!ok");
}

void DMS::on_action_5_triggered()
{
    if(action_5_triggered_flag==0){
        ui->page->setStyleSheet("#page{border-image: url(:/QSS/PCB_P1.png);}");
        action_5_triggered_flag++;
    }
    else
    {
        ui->page->setStyleSheet("");
        action_5_triggered_flag = 0;
    }
}

void DMS::on_tableView_P2_clicked(const QModelIndex &index)
{
    qDebug()<<index;
    int row = ui->tableView_P2->currentIndex().row();
    QStringList stringindex;
    for(int i=0; i<8 ; i++){
        QModelIndex modelindex = model->index(row,i);
        stringindex.append(model->data(modelindex).toString());
    }
    if(!stringindex.isEmpty()){
        QString ID_d = stringindex[0];
        QString name_d = stringindex[1];
        QString format_d = stringindex[2];
        QString class_d = stringindex[3];
        QString path_d = stringindex[4];
        QString tempa_d = stringindex[5];
        QString tempb_d = stringindex[6];
        QString tempc_d = stringindex[7];
        QString rowshow = stringindex.join(" ,");
        ui->textBrowser->setText(rowshow);
        stringindex.clear();
         qDebug()<<ID_d<<name_d<<format_d<<class_d<<path_d<<tempa_d<<tempb_d<<tempc_d;
        adminwidget->ui->textEdit_id->setPlainText(ID_d);
        adminwidget->ui->textEdit_name->setPlainText(name_d);
        adminwidget->ui->textEdit_format->setPlainText(format_d);
        adminwidget->ui->textEdit_class->setPlainText(class_d);
        adminwidget->ui->textEdit_path->setPlainText(path_d);
        adminwidget->ui->textEdit_tempa->setPlainText(tempa_d);
        adminwidget->ui->textEdit_tempb->setPlainText(tempb_d);
        adminwidget->ui->textEdit_tempc->setPlainText(tempc_d);
    }
}

void DMS::on_tableView_P2_doubleClicked(const QModelIndex &index)
{

}

void DMS::on_action_3_triggered()
{
    bool click_ok;
    QString input_text = QInputDialog::getText(this, tr("管理员密码"),tr("请输入管理员密码"), QLineEdit::Password, 0 , &click_ok);
    if(click_ok && !input_text.isEmpty())
    {
        if(input_text == "dms_admin"){
            openadminWidget();
            qDebug()<<"已进入管理员模式！";
        }
        else
        {
            QMessageBox::information(nullptr,"登录失败", "管理员密码错误！\n");
        }
    }
}

void DMS::on_action_Q_triggered()
{
    DMS::close();
    adminwidget->close();
}

void DMS::on_pushButton_P2Updata_clicked()
{
    createTABLE_A();
}

void DMS::on_treeView_P2_doubleClicked(const QModelIndex &index)
{
    qDebug()<<"双击！";
}
