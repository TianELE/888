#include<dms.h>
#include "ui_dms.h"

void DMS::UIcreate()
{
    ui->pushButton_P2Updata->setStyleSheet("QPushButton{border-image: url(:/QSS/update40.png);}"
                                  "QPushButton:hover{border-image: url(:/QSS/update40_1.png);}"
                                  "QPushButton:pressed{border-image: url(:/QSS/update40.png);}");
}
