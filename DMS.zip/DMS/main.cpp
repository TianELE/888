﻿#include "dms.h"

#include <QApplication>
#include <SQLconnection.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    if(!createConnection()){
        return 1;
    }
    DMS w;
    w.show();
    w.style_init();
    return a.exec();
}
