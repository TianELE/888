﻿#ifndef DMS_H
#define DMS_H

#include <QMainWindow>
#include <QTimer>
#include <QDateTime>
#include <QFrame>
#include <QLabel>
#include <QFile>
#include <QApplication>
#include <QDebug>
#include <SQLconnection.h>
#include <qinputdialog.h>
#include <QStandardItemModel>

#include "admin.h"
#include "ui_admin.h"

//#include <qdesktopservices.h>
//#include <QWebEngineView>
//#include <QWebEngineHistory>
//#include <QWebEngineHistoryItem>
//#include <QWebEnginePage>
//#include <QWebEngineView>
//#include <QWebEngineSettings>
//#include <qwebenginepage.h>
//#include <qurl.h>

QT_BEGIN_NAMESPACE
namespace Ui { class DMS; }
QT_END_NAMESPACE

class DMS : public QMainWindow
{
    Q_OBJECT

public:
    DMS(QWidget *parent = nullptr);
    void style_init();
    void style_set();
    int get_random_num();
    void REALtime();
    void time_update();
    void WEB();

    void createTABLE_A();

    void createTreeView_A();

    void UIcreate();



    /*admin界面*/
    void openadminWidget();
    void closeadminWidget();

    uint8_t action_5_triggered_flag = 0;

    ~DMS();

private slots:
    void on_pushButton_A_clicked();

    void on_action_U_triggered();

    void on_action_5_triggered();

    void on_retuen_P2_clicked();

    void on_tableView_P2_clicked(const QModelIndex &index);

    void on_tableView_P2_doubleClicked(const QModelIndex &index);

    void on_action_3_triggered();


    void on_action_Q_triggered();


    void on_pushButton_P2Updata_clicked();

    /*表格操作函数*/
    void del_tab_A();
    void insert_tab_A();

    void on_treeView_P2_doubleClicked(const QModelIndex &index);

private:
    Ui::DMS *ui;
    QLabel *currentTimeLabel;
    QSqlTableModel *model;
    QStandardItemModel *treeviewModel;

    admin *adminwidget = new admin;



//    QWebEngineView *my_web;

};
#endif // DMS_H
